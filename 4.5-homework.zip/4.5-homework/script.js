'use strict'
// Kechagi masala
// let arr = [1, 2, 3, [4, 5, 6]];
// let total = 0;

// for (let i = 0; i < arr.length; i++) {
//     if (typeof arr[i] === 'number') {
//         total += arr[i];
//     } else {
//         for (let j = 0; j < arr[i].length; j++) {
//             if (typeof arr[i][j] === 'number') {
//                 total += arr[i][j];
//             }
//         }
//     }
// }

// console.log(total);

// =============================================================================

// FIRST HOMEWORK

// let arr = [1, 2, 3, [4, 5, 6, '8'], 9];
// let total = 0;

// for (let i = 0; i < arr.length; i++) {
//     if (typeof arr[i] === 'number') {
//         total += arr[i];
//     } else {
//         for (let j = 0; j < arr[i].length; j++) {
//             if (typeof arr[i][j] === 'number') {
//                 total += arr[i][j];
//             }
//         }
//     }
// }

// console.log(total); 

// ============================================================

// SECOND HOMEWORK

// let arr = [1, 2, 3, 'someCode', 'wood', 'Asliddin']
// let str

// for(let i = 0; i < arr.length; i++){
//     if(typeof arr[i] === 'string'){
//         str = arr[i].length
//     }
// }
// console.log(str)

// =============================================================

// THIRD HOMEWORK

// let arr = [1, 2, 3, {Ann:200, John:400, Sam:500, Karl:'500'}]

// let total = 0

// for(let i = 0; i < arr.length; i++){
//     if(typeof arr[i] === 'object'){
//         for(let key in arr[i]){
//             if(typeof arr[i][key] === 'number'){
//                 total += arr[i][key]
//             }
//         }
//     }
// }

// console.log(total)